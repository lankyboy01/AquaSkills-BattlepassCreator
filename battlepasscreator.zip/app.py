
from flask import Flask, render_template, request, send_file, redirect, url_for
import json
import os

app = Flask(__name__)
SAVE_PATH = "battlepass.json"

def load_data():
    if os.path.exists(SAVE_PATH):
        with open(SAVE_PATH, "r") as f:
            content = json.load(f)
            return content.get("rewards", []), content.get("premium_perm", "battlepass.rewardperm.a")
    return [], "battlepass.rewardperm.a"

@app.route('/', methods=['GET', 'POST'])
def index():
    data, stored_perm = load_data()

    if request.method == 'POST':
        if 'load' in request.form:
            return redirect(url_for('index'))

        max_tiers = int(request.form.get('max_tiers', 10))
        premium_perm = request.form.get('premium_perm', stored_perm)

        rewards = []
        for i in range(1, max_tiers + 1):
            free_item = request.form.get(f'free_item_{i}', '').strip()
            free_lore_raw = request.form.get(f'free_lore_{i}', '')
            free_cmd_raw = request.form.get(f'free_cmd_{i}', '')

            premium_item = request.form.get(f'premium_item_{i}', '').strip()
            premium_lore_raw = request.form.get(f'premium_lore_{i}', '')
            premium_cmd_raw = request.form.get(f'premium_cmd_{i}', '')

            free_cmds = [cmd.strip() for cmd in free_cmd_raw.replace('\r', '').splitlines() if cmd.strip()]
            premium_cmds = [cmd.strip() for cmd in premium_cmd_raw.replace('\r', '').splitlines() if cmd.strip()]
            free_lores = [""] + [line.strip() for line in free_lore_raw.replace('\r', '').splitlines() if line.strip()]
            premium_lores = [""] + [line.strip() for line in premium_lore_raw.replace('\r', '').splitlines() if line.strip()]

            entry = {
                "index": i,
                "rewards": {
                    "free": {
                        "rewards": free_cmds,
                        "perms": [""],
                        "display": {
                            "item": free_item,
                            "glow": False,
                            "name": f"Tier {i}",
                            "lore": free_lores
                        },
                        "message": f"You have claimed your Tier {i} rewards!"
                    },
                    "premium": {
                        "rewards": premium_cmds,
                        "perms": [premium_perm],
                        "display": {
                            "item": premium_item,
                            "glow": True,
                            "name": f"Tier {i} Premium",
                            "lore": premium_lores
                        },
                        "message": f"You have claimed your Tier {i} Premium rewards!"
                    }
                }
            }
            rewards.append(entry)

        with open(SAVE_PATH, "w") as f:
            json.dump({"rewards": rewards, "premium_perm": premium_perm}, f, indent=2)

        if 'save' in request.form:
            return redirect(url_for('index'))

        return send_file(SAVE_PATH, as_attachment=True)

    return render_template("editor.html", data=data, stored_perm=stored_perm)

if __name__ == '__main__':
    import webbrowser
    webbrowser.open('http://localhost:5000')
    app.run(debug=False)
